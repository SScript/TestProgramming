package com;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

public class ProcessJsonDataReach {

    protected static JSONObject obj;
    protected static JSONObject orderdata;
    protected static JSONArray orderdataarray;
    protected static JSONArray orderdataitems;
    protected static JSONObject itemdata;
    protected static JSONObject itemattrdata;
    protected static String AccountAddressId = "";
    protected static String ServiceAddressKey = "";
    protected static String NotificationCommType = "";

    public static void main(String[] args) throws Exception {

        FileInputStream fis = new FileInputStream("C:/TestProgramming/TestProgramming/TestStuffs/src/main/java/com/jsonreach1.txt");
        String longJsonString = IOUtils.toString(fis, "UTF-8");

        obj = new JSONObject(longJsonString);
        orderdataarray = obj.getJSONArray("Order");
        orderdata = orderdataarray.getJSONObject(0);
        orderdataitems = orderdata.getJSONArray("OrderItems");

        StringBuilder sb = new StringBuilder();
        sb.append("<JSONXMLNotificationsRequest>");
        sb.append("<ListOfMessages>");
        sb.append("<Message>");

        sb.append(GetJsonObjectValue(obj, "CustomerNo", "customerNo"));
        sb.append(GetJsonObjectValue(obj, "NotificationCommType", "notificationCommType"));
        sb.append(GetJsonObjectValue(obj, "Requester", "requester"));
        sb.append(GetJsonObjectValue(obj, "FirstNotificationStartTime", "firstNotificationStartTime"));
        sb.append(GetJsonObjectValue(obj, "SendingType", "sendingType"));
        sb.append("<notificationaddress_MOBTOKEN/>"); //vienmēr tukšs
        sb.append("<mtetuserid/>"); //vienmēr tukšs
        sb.append("<mobileappid>1</mobileappid>"); //vienmēr 1
        sb.append(GetJsonObjectValue(obj, "Phone", "notificationaddress_SMS"));
        sb.append(GetJsonObjectValue(obj, "Email", "notificationaddress_EMAIL"));

        sb.append("<DynamicParametersList>");
        
        //actioncode -> vēl no galvenā bloka
        sb.append("<DynamicParameter>").append("<Key>").append("actioncode").append("</Key>")
                    .append(GetJsonObjectValue(obj, "Actioncode", "Value"))
                .append("</DynamicParameter>");
        
        //ReadyMadeAddress
        if ("VLOCITY_NOTIF_1".equals(NotificationCommType)) {
            sb.append("<DynamicParameter>").append("<Key>").append("ReadyMadeAddress").append("</Key>")
                    .append("<Value>").append("Y").append("</Value>").append("</DynamicParameter>");
        } else {
            sb.append("<DynamicParameter>").append("<Key>").append("ReadyMadeAddress").append("</Key>")
                    .append("<Value>").append("N").append("</Value>").append("</DynamicParameter>");
        }
        
        //VLOrderId
        sb.append("<DynamicParameter>").append("<Key>").append("VLOrderId").append("</Key>")
                .append("<Value>")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderNumber")))
                .append("</Value>").append("</DynamicParameter>");
        
        //VLOrderCustomerName
        sb.append("<DynamicParameter>").append("<Key>").append("VLOrderCustomerName").append("</Key>")
                .append("<Value>")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderCustomerName")))
                .append("</Value>").append("</DynamicParameter>");
        
        //VLOrderDeliveryType
        sb.append("<DynamicParameter>").append("<Key>").append("VLOrderDeliveryType").append("</Key>")
                .append("<Value>")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderCustomerName")))
                .append("</Value>").append("</DynamicParameter>");
        
        //VLOrderDeliveryAddress
        //Ja <VLOrderDeliveryType> = 'DPD Courier', tad Addressconcat no AK_ADMIN db tabulas LTK_FULL_ADDRESSES_MD, meklēt pēc addresskey = <VLOrderDeliveryAddress>,
        //Ja <VLOrderDeliveryType> = 'Store front', tad <VLWarehauserName>.
        //Pārējos gadījumos - <VLPickUpPoint>.
        String VLOrderDeliveryType = GetJsonAtrrObjectStringValue(orderdata.get("VLOrderDeliveryType"));
        switch (VLOrderDeliveryType) {
            case "DPD Courier":

                break;
            case "Store front":
                sb.append("<DynamicParameter>").append("<Key>").append("VLOrderDeliveryAddress").append("</Key>")
                        .append("<Value>")
                        .append(GetJsonAtrrObjectStringValue(orderdata.get("VLWarehauserName")))
                        .append("</Value>").append("</DynamicParameter>");
                break;
            default:
                sb.append("<DynamicParameter>").append("<Key>").append("VLOrderDeliveryAddress").append("</Key>")
                        .append("<Value>")
                        .append(GetJsonAtrrObjectStringValue(orderdata.get("VLPickUpPoint")))
                        .append("</Value>").append("</DynamicParameter>");
                break;
        }
        //VLOrderContactData
        sb.append("<DynamicParameter>").append("<Key>").append("VLOrderContactData").append("</Key>")
                .append("<Value>")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderContactName")))
                .append(", ")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderContactPhone")))
                .append(", ")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderContactEmail")))
                .append("</Value>").append("</DynamicParameter>");
        //VLOrderTotal
        sb.append("<DynamicParameter>").append("<Key>").append("VLOrderDeliveryAddress").append("</Key>")
                .append("<Value>")
                .append(GetJsonAtrrObjectStringValue(orderdata.get("VLOrderTotal")))
                .append("</Value>").append("</DynamicParameter>");
        
        //VLOrderFstPayment
        String VLOrderFstPayment = GetVLOrderFstPaymentValue();
        if (!isEmptyOrNull(VLOrderFstPayment)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderFstPayment").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderFstPayment)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }
        
        //VLOrderDeliveryCharge
        String VLOrderDeliveryCharge = GetVLOrderDeliveryChargeValue();
        if (!isEmptyOrNull(VLOrderDeliveryCharge)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderDeliveryCharge").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderDeliveryCharge)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }
        //VLOrderInstallmentPeriod
        String VLOrderInstallmentPeriod = GetVLOrderInstallmentPeriodValue();
        if (!isEmptyOrNull(VLOrderDeliveryCharge)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderInstallmentPeriod").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderInstallmentPeriod)
                    .append("</Value>")
                .append("</DynamicParameter>");            
        }
        //VLOrderInstallmentMonthPaym
        String VLOrderInstallmentMonthPaym = GetVLOrderInstallmentMonthPaymValue();
        if (!isEmptyOrNull(VLOrderInstallmentMonthPaym)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderInstallmentMonthPaym").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderInstallmentMonthPaym)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }
        
        //EstimateDeliveryTime -> vēl no galvenā bloka
        sb.append("<DynamicParameter>").append("<Key>").append("EstimateDeliveryTime").append("</Key>")
                    .append(GetJsonObjectValue(orderdata, "EstimateDeliveryTime", "Value"))
                .append("</DynamicParameter>");
        
        //VLBillNumber
        sb.append("<DynamicParameter>").append("<Key>").append("VLBillNumber").append("</Key>")
                    .append(GetJsonObjectValue(orderdata, "VLBillNumber", "Value"))
                .append("</DynamicParameter>");
        
        //VLAgreementNumber
        sb.append("<DynamicParameter>").append("<Key>").append("VLAgreementNumber").append("</Key>")
                    .append(GetJsonObjectValue(orderdata, "VLAgreementNumber", "Value"))
                .append("</DynamicParameter>");
        
        //VLSaleChannel
        sb.append("<DynamicParameter>").append("<Key>").append("VLSaleChannel").append("</Key>")
                    .append(GetJsonObjectValue(orderdata, "VLSaleChannel", "Value"))
                .append("</DynamicParameter>");
        
        //VLOrderItemX fields
        String VLOrderItemXFields = GetVLOrderItemXFields();
        if (!isEmptyOrNull(VLOrderItemXFields)) {
            sb.append(VLOrderItemXFields);
        }

        //VLOrderInsurance
        String VLOrderInsurance = GetVLOrderInsuranceValue();
        if (!isEmptyOrNull(VLOrderInsurance)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderInsurance").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderInsurance)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }

        //VLOrderWarranty 
        String VLOrderWarranty = GetVLOrderWarrantyValue();
        if (!isEmptyOrNull(VLOrderWarranty)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderWarranty").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderWarranty)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }

        //VLOrderPersonLiability
        String VLOrderPersonLiability = GetVLOrderPersonLiabilityValue();
        if (!isEmptyOrNull(VLOrderPersonLiability)) {
            sb.append("<DynamicParameter>").append("<Key>").append("VLOrderPersonLiability").append("</Key>")
                    .append("<Value>")
                        .append(VLOrderInsurance)
                    .append("</Value>")
                .append("</DynamicParameter>");
        }        
        
        sb.append("</DynamicParametersList>");

        sb.append("</Message>");
        sb.append("</ListOfMessages>");
        sb.append("</JSONXMLNotificationsRequest>");

        System.out.println(sb.toString());
        FileUtils.writeStringToFile(new File("C:/TestProgramming/TestProgramming/TestStuffs/src/main/java/com/resReach1.json"),
                sb.toString(), Charset.forName("UTF-8"));
    }

    /**
     * OrderItems.VLOneTimeCharge, where ProductType = Insurance
     */
    private static String GetVLOrderInsuranceValue() {
        String result = "";
        String finalRes = "";
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("Insurance".equals(ProductType)) {
                finalRes =  GetJsonAtrrObjectStringValue(itemdata.get("VLOneTimeCharge"));
            }
        }
        return String.valueOf(finalRes);
    }
    
     /**
     * OrderItems.VLOneTimeCharge, where ProductType = Insurance
     */
    private static String GetVLOrderPersonLiabilityValue() {
        String result = "";
        String finalRes = "";
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("PersonalLiabilityInsurance".equals(ProductType)) {
                finalRes =  GetJsonAtrrObjectStringValue(itemdata.get("VLOneTimeCharge"));
            }
        }
        return String.valueOf(finalRes);
    }
    
     /**
     * OrderItems.VLOneTimeCharge, where ProductType = Warranty
     */
    private static String GetVLOrderWarrantyValue() {
        String result = "";
        String finalRes = "";
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("Warranty".equals(ProductType)) {
                finalRes =  GetJsonAtrrObjectStringValue(itemdata.get("VLOneTimeCharge"));
            }
        }
        return String.valueOf(finalRes);
    }
    
    private static String GetVLOrderItemXFields() {
        StringBuilder sb = new StringBuilder();
        
        int itemcount = orderdataitems.length();
        String fieldName = "";
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            fieldName = "VLOrderItem" + (i + 1) + "Name";
            sb.append("<DynamicParameter>").append("<Key>").append(fieldName).append("</Key>")
                    .append(GetJsonObjectValue(itemdata, "Name", "Value"))
                .append("</DynamicParameter>");
            
            fieldName = "VLOrderItem" + (i + 1) + "Amount";
            sb.append("<DynamicParameter>").append("<Key>").append(fieldName).append("</Key>")
                    .append(GetJsonObjectValue(itemdata, "VLOneTimeCharge", "Value"))
                .append("</DynamicParameter>");
            
            fieldName = "VLOrderItem" + (i + 1) + "Picture";
            sb.append("<DynamicParameter>").append("<Key>").append(fieldName).append("</Key>")
                    .append(GetJsonObjectValue(itemdata, "Picture", "Value"))
                .append("</DynamicParameter>");
            
            fieldName = "VLOrderItem" + (i + 1) + "AddInfo1";
            sb.append("<DynamicParameter>").append("<Key>").append(fieldName).append("</Key>")
                    .append(GetJsonObjectValue(itemdata, "AddInfo1", "Value"))
                .append("</DynamicParameter>");
        }
        return sb.toString();
    }
    /**
     * OGetVLOrderInstallmentPeriodValue Value from OrderItems attribute "Term"
     * where ProductType = SplitPayment
     */
    private static String GetVLOrderInstallmentPeriodValue() {
        String res = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            String ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("SplitPayment".equals(ProductType)) {
                try {
                    JSONObject atrr = itemdata.getJSONObject("JSONAttribute");
                    Iterator<String> keys = atrr.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        JSONArray a = atrr.getJSONArray(key);
                        int itemattrcount = a.length();
                        for (int j = 0; j < itemattrcount; j++) {
                            itemattrdata = a.getJSONObject(j);
                            String valp = GetJsonObjectItemAttrValue("attributedisplayname__c");
                            if ("Term".equals(valp)) {
                                res = GetJsonAtrrObjectStringValue(itemattrdata.getJSONObject("attributeRunTimeInfo").get("value"));
                            }
                        }
                    }
                    
                } catch (Exception e) {
                    res = "";
                }
            }
        }
        
        return res;
    }

    /**
     * Month payment
     * OrderItems.VLRecurringCharge where  ProductType = SplitPayment
     */
    private static String GetVLOrderInstallmentMonthPaymValue() {
        String result = "";
        String finalRes = "";
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            //SplitPayment
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("SplitPayment ".equals(ProductType)) {
                finalRes =  GetJsonAtrrObjectStringValue(itemdata.get("VLOrderInstallmentMonthPaym"));
            }
        }
        return String.valueOf(finalRes);
    }
    
    /**
     * Order delivery charge - summa no visiem piegādes produktu cenam
     * OrderItems.VLOneTimeCharge, where ProductType = Shipping 
    *
     */
    private static String GetVLOrderDeliveryChargeValue() {
        String result = "";
        double finalResCount = 0;
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            //SplitPayment
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("Shipping ".equals(ProductType)) {
                finalResCount = finalResCount + Double.valueOf(GetJsonAtrrObjectStringValue(itemdata.get("VLOneTimeCharge")));
            }
        }
        return String.valueOf(finalResCount);
    }

    /**
     * First payment amount 
     * OrderItems.VLOneTimeCharge, where ProductType = Shipping
     */
    private static String GetVLOrderFstPaymentValue() {
        String result = "";
        double finalResCount = 0;
        String ProductType = "";
        int itemcount = orderdataitems.length();
        for (int i = 0; i < itemcount; i++) {
            itemdata = orderdataitems.getJSONObject(i);
            //SplitPayment
            ProductType = GetJsonAtrrObjectStringValue(itemdata.get("ProductType"));
            if ("SplitPayment".equals(ProductType)) {
                finalResCount = finalResCount + Double.valueOf(GetJsonAtrrObjectStringValue(itemdata.get("VLOneTimeCharge")));
            }
        }
        return String.valueOf(finalResCount);
    }

    private static String GetJsonAtrrObjectStringValue(Object objvalue) {
        String valToXml = "";
        if (objvalue instanceof Boolean) {
            Boolean boolToUse = ((Boolean) objvalue).booleanValue();
            valToXml = boolToUse.toString();
        } else if (objvalue instanceof Integer || objvalue instanceof Long) {
            long intToUse = ((Number) objvalue).longValue();
            valToXml = String.valueOf(intToUse);
        } else if (objvalue instanceof Float || objvalue instanceof Double) {
            double floatToUse = ((Number) objvalue).doubleValue();
            valToXml = String.valueOf(floatToUse);
        } else if (JSONObject.NULL.equals(objvalue)) {
            valToXml = "";
        } else {
            valToXml = ((String) objvalue).toString();
        }

        return valToXml;
    }

    private static String GetJsonObjectValue(JSONObject data, String jsonfieldName, String xmlfieldname) {
        String valToXml = "";
        try {
            Object objvalue = data.get(jsonfieldName);
            if (objvalue instanceof Boolean) {
                Boolean boolToUse = ((Boolean) objvalue).booleanValue();
                valToXml = boolToUse.toString();
            } else if (objvalue instanceof Integer || objvalue instanceof Long) {
                long intToUse = ((Number) objvalue).longValue();
                valToXml = String.valueOf(intToUse);
            } else if (objvalue instanceof Float || objvalue instanceof Double) {
                double floatToUse = ((Number) objvalue).doubleValue();
                valToXml = String.valueOf(floatToUse);
            } else if (JSONObject.NULL.equals(objvalue)) {
                valToXml = "";
            } else {
                valToXml = data.getString(jsonfieldName);
            }
        } catch (Exception e) {
            valToXml = "";
        }

        switch (jsonfieldName) {
            case "NotificationCommType":
                NotificationCommType = valToXml;
                break;

        }

        if (!isEmptyOrNull(valToXml)) {
            return "<" + xmlfieldname + ">" + valToXml + "</" + xmlfieldname + ">";
        } else {
            return "<" + xmlfieldname + "/>";
        }
    }

    private static String GetJsonObjectItemAttrValue(String fieldName) {
        try {
            return itemattrdata.getString(fieldName);
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean isNull(Object obj) {
        if (null == obj) {
            return true;
        }

        return false;
    }

    private static boolean isEmptyOrNull(String str) {
        if (null == str || (null != str && str.trim().equals(""))) {
            return true;
        }

        return false;
    }

}
