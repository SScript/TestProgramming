package com;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

public class BillingTrigger {

    protected static JSONObject obj;
    protected static JSONObject orderdata;
    protected static JSONArray orderdataitems;
    protected static JSONObject itemdata;
    protected static JSONObject itemattrdata;
    protected static JSONObject jsonData = new JSONObject();
    protected static JSONArray orderAtrrItems = new JSONArray();
    protected static boolean isOrderItems = true;

    public static void main(String[] args) throws Exception {
        FileInputStream fis = new FileInputStream("C:/TestProgramming/TestProgramming/TestStuffs/src/main/java/com/BillTriggerInput.txt");
        String longJsonString = IOUtils.toString(fis, "UTF-8");
        orderdata = new JSONObject(longJsonString);

        // OrderItems var nebūt
        try {
            orderdataitems = orderdata.getJSONArray("OrderItems");
        } catch (Exception e) {
            isOrderItems = false;
        }

        // TriggerBilling gadījumā ir prasība likt visus parametrus, ja mav vērtība, tad liek tukšu ""
        jsonData
                .put("orderid", GetOrderFieldFirstLEvelValue("OrderId"))
                .put("orderno", GetOrderFieldFirstLEvelValue("OrderNumber"))
                //.put("serviceno", GetOrderFieldFirstLEvelValue("serviceno"))
                .put("orderdate", GetOrderFieldFirstLEvelValue("OrderDate"))
                .put("ordernotes", GetOrderFieldFirstLEvelValue("Notes"))
                .put("caller", GetOrderFieldFirstLEvelValue("Requester"));

        try {
            String val = GetOrderFieldFirstLEvelValue("PaymentMode");
            switch (val) {
                case "Split Payment":
                    orderAtrrItems.put(new JSONObject().put("ORD_PAYMENT_TYPE", "SP"));
                    break;
                case "Full Payment":
                    orderAtrrItems.put(new JSONObject().put("ORD_PAYMENT_TYPE", "FP"));
                    orderAtrrItems.put(new JSONObject().put("serviceno", GetOrderFieldFirstLEvelValue("OrderNumber")));
                    break;
                default:
                    orderAtrrItems.put(new JSONObject().put("ORD_PAYMENT_TYPE", ""));
                    orderAtrrItems.put(new JSONObject().put("serviceno", ""));
                    break;
            }
        } catch (Exception e) {
        }

        orderAtrrItems.put(new JSONObject().put("value", GetIsOrderItem("Insurance")).put("key", "ORD_INSURANCE_FLAG"));
        orderAtrrItems.put(new JSONObject().put("value", GetIsOrderItem("Warranty")).put("key", "ORD_WARRANTY_FLAG"));
        orderAtrrItems.put(new JSONObject().put("value", GetIsOrderItem("PersonalLiabilityInsurance")).put("key", "ORD_CTA_FLAG"));

        orderAtrrItems.put(new JSONObject().put("value", "").put("key", "ORD_CTA_SUM"));

        // saliekam atribūtus
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("AccountNo", "ORD_CUSTOMERNO"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("BillAccountNumber", "ORD_BILLINGACCOUNTNO"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("DownPaymentBillNo", "ORD_DP_BILL_NO"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("MonthDelay", "ORD_MONTH_DELAY"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("BillActivationDate", "ORD_BILLING_ACTIVATION_DATE"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("OrderedService", "ORD_ORDEREDSERVICE"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("OrderedServiceType", "ORD_ORDEREDSERVICETYPE"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("RemovalReason", "ORD_REASON_ID"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("PaymentDelayPercents", "ORD_PAYMENT_DELAY_PERCENT"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("PaymentDelayMonths", "ORD_PAYMENT_DELAY_MONTHS"));
        orderAtrrItems.put(GetOrderFirstLevelAtrrValue("RepayMonths", "ORD_REPAY_MONTHS"));

        GetOrderItemLevelAtrrValue("SplitPayment", "OrderItemId", "OrderItemId");
        GetOrderItemLevelAtrrValue("SplitPayment", "ServiceId", "serviceno");
        GetOrderItemLevelAtrrValue("SplitPayment", "OneTimeCharge", "ORD_FIRST_PAYMENT");
        GetOrderItemLevelAtrrValue("SplitPayment", "RecurringCharge", "ORD_INSTALLMENT_SUM");

        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Term", "ORD_MONTHS");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Term", "ORD_INSURANCE_MONTHS");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Term", "ORD_WARRANTY_MONTHS");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Total", "ORD_INSURANCE_SUM");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Insurance", "ORD_INSURANCE_MONTHS_DELAY");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Total Warranty", "ORD_WARRANTY_SUM");
        GetOrderItemLevelAtrrDinamicValue("SplitPayment", "Warranty Delayed Months", "ORD_WARRANTY_MONTHS_DELAY");

        GetOrderItemLevelAtrrValue("Shipping", "AccountingCode", "ORD_COURIERPRODUCTID");
        GetOrderItemLevelAtrrValue("Shipping", "OneTimeCharge", "ORD_COURIERCHARGE");

        GetOrderItemLevelAtrrValue("PersonalLiabilityInsurance", "Term", "ORD_CTA_MONTHS");

        GetOrderItemLevelAtrrValue("SplitPayment", "Warranty Delayed Months", "ORD_CTA_MONTHS_DELAY");

        jsonData.put("orderdetails", orderAtrrItems);

        System.out.println(jsonData.toString());
        FileUtils.writeStringToFile(new File("C:/TestProgramming/TestProgramming/TestStuffs/src/main/java/com/resBillTrigger.json"),
                jsonData.toString(), Charset.forName("UTF-8"));
    }

    private static String GetOrderProductTypeList() {
        String res = "";
        if (isOrderItems) {
            int itemcount = orderdataitems.length();
            String productTypeValue = "";
            for (int i = 0; i < itemcount; i++) {
                itemdata = orderdataitems.getJSONObject(i);
                if (isEmptyOrNull(res)) {
                    res = GetJsonObjectStringValue(itemdata.get("ProductType"));
                } else {
                    res = res + "," + GetJsonObjectStringValue(itemdata.get("ProductType"));
                }
            }
        }
        return res;
    }

    private static String GetIsOrderItem(String val) {
        String res = "N";
        if (isOrderItems) {
            int itemcount = orderdataitems.length();
            String productTypeValue = "";
            for (int i = 0; i < itemcount; i++) {
                itemdata = orderdataitems.getJSONObject(i);
                productTypeValue = GetJsonObjectStringValue(itemdata.get("ProductType"));
                if (val.equals(productTypeValue)) {
                    res = "Y";
                    break;
                }
            }
        }
        return res;
    }

    /**
     * Order pirmā līmeņa parametrs
     *
     * @return
     */
    private static String GetOrderFieldFirstLEvelValue(String field) {
        try {
            return GetJsonObjectStringValue(orderdata.get(field));
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Order pirmā līmeņa atribūtu parametrs
     *
     * @return
     */
    private static JSONObject GetOrderFirstLevelAtrrValue(String field, String key) {
        String val = "";
        try {
            val = GetJsonObjectStringValue(orderdata.get(field));
        } catch (Exception e) {
            val = "";
        }
        return new JSONObject().put("value", val).put("key", key);
    }

    /**
     * Order pirmā līmeņa atribūtu parametrs
     *
     * @return
     */
    private static void GetOrderItemLevelAtrrValue(String productType, String field, String key) {
        // ja ir padoti orderitems
        if (isOrderItems) {
            int itemcount = orderdataitems.length();
            // meklējam atbilsošo item pēc productType
            String productTypeValue = "";
            String val = "";
            String newkey = "";
            int counter = 0;
            for (int i = 0; i < itemcount; i++) {
                itemdata = orderdataitems.getJSONObject(i);
                productTypeValue = GetJsonObjectStringValue(itemdata.get("ProductType"));
                if (productType.equals(productTypeValue)) {
                    if (counter > 0) {
                        newkey = key + "_" + counter;
                    } else {
                        newkey = key;
                    }
                    //return new JSONObject().put("value", GetJsonObjectStringValue(itemdata.get(field))).put("key", key);
                    try {
                        val = GetJsonObjectStringValue(itemdata.get(field));
                    } catch (Exception e) {
                        val = "";
                    }
                    orderAtrrItems.put(new JSONObject().put("value", val).put("key", newkey));
                    counter++;
                }
            }

        } else {
            orderAtrrItems.put(new JSONObject().put("value", "").put("key", key));
        }
        //orderAtrrItems.put(new JSONObject().put("value", "").put("key", key));
    }

    private static void GetOrderItemLevelAtrrDinamicValue(String productType, String atrribute, String key) {
        if (isOrderItems) {
            int itemcount = orderdataitems.length();
            // meklējam atbilsošo item pēc productType
            String ProductType = "";
            String atrrname = "";
            int counter = 0;
            for (int i = 0; i < itemcount; i++) {
                itemdata = orderdataitems.getJSONObject(i);
                ProductType = GetJsonObjectStringValue(itemdata.get("ProductType"));
                if (productType.equals(ProductType)) {
                    try {

                        JSONObject atrr = itemdata.getJSONObject("JSONAttribute");
                        Iterator<String> keys = atrr.keys();
                        while (keys.hasNext()) {
                            String nkey = keys.next();
                            JSONArray a = atrr.getJSONArray(nkey);
                            int itemattrcount = a.length();
                            String val = "";
                            String newkey = "";
                            for (int j = 0; j < itemattrcount; j++) {
                                itemattrdata = a.getJSONObject(j);
                                String datatypr = GetJsonObjectStringValue(itemattrdata.get("valuedatatype__c"));
                                String valp = GetJsonObjectStringValue(itemattrdata.get("attributedisplayname__c"));
                                if (atrribute.equals(valp)) {
                                    if ("Picklist".equals(valp)) {
                                        try {
                                            val = GetJsonObjectStringValue(itemattrdata.getJSONObject("attributeRunTimeInfo")
                                                    .getJSONObject("selectedItem").get("value"));
                                        } catch (Exception e) {
                                            val = "";
                                        }
                                    } else {
                                        try {
                                            val = GetJsonObjectStringValue(itemattrdata.getJSONObject("attributeRunTimeInfo").get("value"));
                                        } catch (Exception e) {
                                            val = "";
                                        }
                                    }
                                    if (counter > 0) {
                                        newkey = key + "_" + counter;
                                    } else {
                                        newkey = key;
                                    }
                                    orderAtrrItems.put(new JSONObject().put("value", val).put("key", newkey));
                                    counter++;
                                    //res = GetJsonAtrrObjectStringValue(itemattrdata.get("attributeRunTimeInfo"));

                                }
                            }
                        }

                    } catch (Exception e) {
                        orderAtrrItems.put(new JSONObject().put("value", "").put("key", key));
                    }
                }

            }
        } else {
            orderAtrrItems.put(new JSONObject().put("value", "").put("key", key));
        }

        //orderAtrrItems.put(new JSONObject().put("value", "").put("key", key));
    }

    private static String GetJsonObjectStringValue(Object objvalue) {
        String valToXml = "";
        try {
            if (objvalue instanceof Boolean) {
                Boolean boolToUse = ((Boolean) objvalue).booleanValue();
                valToXml = boolToUse.toString();
            } else if (objvalue instanceof Integer || objvalue instanceof Long) {
                long intToUse = ((Number) objvalue).longValue();
                valToXml = String.valueOf(intToUse);
            } else if (objvalue instanceof Float || objvalue instanceof Double) {
                double floatToUse = ((Number) objvalue).doubleValue();
                valToXml = String.valueOf(floatToUse);
            } else if (JSONObject.NULL.equals(objvalue)) {
                valToXml = "";
            } else {
                valToXml = ((String) objvalue).toString();
            }
        } catch (Exception e) {
            valToXml = "";
        }

        return valToXml;
    }

    private static boolean isEmptyOrNull(String str) {
        if (null == str || (null != str && str.trim().equals(""))) {
            return true;
        }
        return false;
    }
}
